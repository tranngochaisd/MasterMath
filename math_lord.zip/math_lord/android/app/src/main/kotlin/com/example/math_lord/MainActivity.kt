package com.example.math_lord

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
